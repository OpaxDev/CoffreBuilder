CoffreBuilder = {
    {
        Point = vector3(-1092.306, -811.3735, 4.47986), 
        NameJob = "police", 
        LabelJob = "Police",
        Society = "society_police",
        GradeJob = {"boss", "lieutenant"}
    },
    {
        Point = vector3(-1088.869, -813.7664, 5.479686), 
        NameJob = "burgershot", 
        LabelJob = "Bugershot",
        Society = "society_burgershot",
        GradeJob = {"boss"}
    },
}